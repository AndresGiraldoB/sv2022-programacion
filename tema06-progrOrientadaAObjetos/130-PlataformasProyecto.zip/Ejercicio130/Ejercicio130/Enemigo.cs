﻿using System;

class Enemigo
{
    private int x;
    private bool desaparecido = false;

    public void MoverIzquierda()
    {
        x--;
    }    

    public void MoverDerecha()
    {
        x++;
    }    

    public void Golpear()
    {

    }    

    public void Desaparecer()
    {
        desaparecido = true;
    }
}
