﻿using System;

class Partida
{
    public void SeleccionarMundo()
    {
    }
}

