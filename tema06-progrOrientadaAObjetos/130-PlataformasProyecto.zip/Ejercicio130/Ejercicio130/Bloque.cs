﻿using System;

class Bloque
{
    private bool estarRoto = false;
    
    public void Romper()
    {
        estarRoto = true;
    }
}

