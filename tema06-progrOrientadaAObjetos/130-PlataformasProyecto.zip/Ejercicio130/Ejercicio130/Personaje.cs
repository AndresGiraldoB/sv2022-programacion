﻿using System;

class Personaje
{
    private int x, y;

    public void MoverIzquierda()
    {
        x--;
    }
    public void MoverDerecha()
    {
        x++;
    }

    public void Saltar()
    {

    }

    public void CogerMoneda()
    {

    }
}

