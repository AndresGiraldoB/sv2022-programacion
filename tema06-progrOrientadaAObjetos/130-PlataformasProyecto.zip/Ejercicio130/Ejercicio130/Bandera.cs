﻿using System;

class Bandera
{
    public void MostrarFinPartida()
    {

    }
}

