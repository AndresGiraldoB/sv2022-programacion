﻿using System;


class ObjetoEstatico
{
    private int x, y;

}

