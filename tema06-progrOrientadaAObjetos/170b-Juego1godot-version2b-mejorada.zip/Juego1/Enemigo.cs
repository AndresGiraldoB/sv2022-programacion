using Godot;
using System;

public class Enemigo : Area2D
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";
	private Vector2 velocidad;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		velocidad = new Vector2(150, 0);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(float delta)
	{
		Position += velocidad * delta;
		if (Position.x > 900)
		{
			velocidad = new Vector2(-150, 0);
		}
		if (Position.x < 100)
		{
			velocidad = new Vector2(150, 0);
		} 
	}
}
