using Godot;
using System;

public class Personaje : Area2D
{
	private int velocidad = 200;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(float delta)
	{
	 	if (Input.IsActionPressed("ui_right"))
		{
			Position += new Vector2(velocidad * delta, 0);
		}
		else if (Input.IsActionPressed("ui_left"))
		{
			Position += new Vector2(-velocidad * delta, 0);
		}
		else if (Input.IsActionPressed("ui_up"))
		{
			Position += new Vector2(0, -velocidad * delta);
		}
		else if (Input.IsActionPressed("ui_down"))
		{
			Position += new Vector2(0, velocidad * delta);
		} 
	}
}
