using Godot;
using System;

public class Item : Area2D
{
	public override void _Ready()
	{
		
	}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }

	private void _on_Item_area_entered(Area2D otro)
	{
		if (otro.Name == "Personaje")
		{
			// GD.Print("Chocado");
			GetParent().Call("IncrementarPuntos");
			QueueFree();
		}
	}
}



