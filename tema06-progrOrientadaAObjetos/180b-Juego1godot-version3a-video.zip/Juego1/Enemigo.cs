using Godot;
using System;

public class Enemigo : Area2D
{
	private int velocidad;
	private EscenaDeJuego juego;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		velocidad = 50;
		juego = GetNode<EscenaDeJuego>("/root/EscenaDeJuego");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(float delta)
	{
		Vector2 posPersonaje = juego.GetPosicionPersonaje();
		Vector2 distancia = posPersonaje - Position;
		Position += distancia.Normalized() * velocidad * delta;
		
		/*
		Position += velocidad * delta;
		if (Position.x > 900)
		{
			velocidad = new Vector2(-150, 0);
		}
		if (Position.x < 100)
		{
			velocidad = new Vector2(150, 0);
		} 
		*/
	}
}
