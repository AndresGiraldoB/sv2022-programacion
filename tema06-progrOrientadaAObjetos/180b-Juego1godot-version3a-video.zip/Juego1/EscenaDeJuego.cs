using Godot;
using System;

public class EscenaDeJuego : Node2D
{
	private int puntos = 0;
	private Personaje personaje;
	private PackedScene objeto;
	private float tiempoEspera;
	private float tiempoEntreCaidas;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		personaje = GetNode<Personaje>("/root/EscenaDeJuego/Personaje");			
		objeto = GD.Load<PackedScene>("res://ObjetoQueCae.tscn");
		GD.Randomize();
		tiempoEntreCaidas = 2.0f;
		tiempoEspera = 0;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(float delta)
	{
		tiempoEspera += delta;
		if (tiempoEspera > tiempoEntreCaidas)
		//if (Input.IsKeyPressed((int) KeyList.Space))
		{
			//GD.Print("Cayendo");
			var objetoCae = objeto.Instance();
			AddChild(objetoCae);
			tiempoEspera = 0;
		}
	}

	public void IncrementarPuntos()
	{
		puntos += 10;
		// GD.Print("Puntos: " + puntos);
		Interfaz iu = GetNode<Interfaz>(
			"/root/EscenaDeJuego/CanvasLayer/Interfaz");
		iu.ActualizarPuntos(puntos);
	}
	
	public Vector2 GetPosicionPersonaje()
	{
		return personaje.Position;
	}
}
