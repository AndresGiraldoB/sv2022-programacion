using Godot;
using System;

public class Personaje : Area2D
{
	private int velocidad = 200;
	private AnimatedSprite sprite;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		sprite = GetNode<AnimatedSprite>("AnimatedSprite");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(float delta)
	{
	 	if (Input.IsActionPressed("ui_right"))
		{
			Position += new Vector2(velocidad * delta, 0);
			sprite.Play("derecha");
		}
		else if (Input.IsActionPressed("ui_left"))
		{
			Position += new Vector2(-velocidad * delta, 0);
			sprite.Play("izquierda");
		}
		else if (Input.IsActionPressed("ui_up"))
		{
			Position += new Vector2(0, -velocidad * delta);
		}
		else if (Input.IsActionPressed("ui_down"))
		{
			Position += new Vector2(0, velocidad * delta);
		} 
		else
		{
			sprite.Play("default");
		}
	}
}
