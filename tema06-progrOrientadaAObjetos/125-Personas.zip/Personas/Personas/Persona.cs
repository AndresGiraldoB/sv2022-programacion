﻿// Francis (...) - 1ºDAM Semipresencial

/*
 * 125. Crea una nueva versión del ejercicio 124 (clase Persona y clase 
 * PruebaDePersona), creando un proyecto en el que cada clase esté en
 * un fichero independiente. Deberás emplear Visual Studio y entregar 
 * toda la carpeta del proyecto de Visual Studio, comprimida en formato ZIP.
 */

using System;
class Persona
{
    private string nombre;
    private byte edad;
    private string eMail;

    public string GetNombre() { return nombre; }
    public byte GetEdad() { return edad; }
    public string GetEmail() { return eMail; }

    public void SetNombre(string nuevoNombre) { nombre = nuevoNombre; }
    public void SetEdad(byte nuevaEdad) { edad = nuevaEdad; }
    public void SetEmail(string nuevoEmail) { eMail = nuevoEmail; }

    public void Mostrar()
    {
        Console.WriteLine("{0}, {1} años. Correo: {2}", nombre, edad, eMail);
    }
}