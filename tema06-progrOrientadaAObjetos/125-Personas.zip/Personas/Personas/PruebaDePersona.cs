﻿// Francis (...) - 1ºDAM Semipresencial

/*
 * 125. Crea una nueva versión del ejercicio 124 (clase Persona y clase 
 * PruebaDePersona), creando un proyecto en el que cada clase esté en
 * un fichero independiente. Deberás emplear Visual Studio y entregar 
 * toda la carpeta del proyecto de Visual Studio, comprimida en formato ZIP.
 */

using System;
class PruebaDePersona
{
    static void Main()
    {
        // Datos de la primera persona
        Console.WriteLine("------ Persona 1 ------");
        Persona p1 = new Persona();
        Console.Write("Nombre: ");
        p1.SetNombre(Console.ReadLine());
        Console.Write("Edad: ");
        p1.SetEdad(Convert.ToByte(Console.ReadLine()));
        Console.Write("Email: ");
        p1.SetEmail(Console.ReadLine());
        Console.WriteLine();

        // Datos de la segunda persona
        Console.WriteLine("------ Persona 2 ------");
        Persona p2 = new Persona();
        Console.Write("Nombre: ");
        p2.SetNombre(Console.ReadLine());
        Console.Write("Edad: ");
        p2.SetEdad(Convert.ToByte(Console.ReadLine()));
        Console.Write("Email: ");
        p2.SetEmail(Console.ReadLine());
        Console.WriteLine();

        // Mostrar datos de las personas
        p1.Mostrar();
        p2.Mostrar();
    }
}