﻿using System;

class PruebaDeLibro
{
    static void Main()
    {
        Libro l = new Libro();
        l.SetAutor("Stephen King");
        l.SetTitulo("It");
        l.SetUbicacion("Est.1, Balda 2");
        l.MostrarDetalles();

        Console.WriteLine();

        Console.WriteLine(l.GetAutor());
        l.SetTitulo("La larga marcha");

        l.MostrarDetalles();
    }
}

