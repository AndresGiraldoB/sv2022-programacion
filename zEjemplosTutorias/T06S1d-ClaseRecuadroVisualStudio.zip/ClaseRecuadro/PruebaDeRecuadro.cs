﻿using System;

class PruebaDeRecuadro
{
    static void Main()
    {
        Recuadro r1 = new Recuadro();
        r1.SetX(10);
        r1.SetY(2);
        r1.SetAnchura(40);
        r1.SetAltura(5);
        r1.Dibujar();

        Recuadro r2 = new Recuadro();
        r2.SetX(20);
        r2.SetY(4);
        r2.SetAnchura(20);
        r2.SetAltura(10);
        r2.Dibujar();
    }
}

